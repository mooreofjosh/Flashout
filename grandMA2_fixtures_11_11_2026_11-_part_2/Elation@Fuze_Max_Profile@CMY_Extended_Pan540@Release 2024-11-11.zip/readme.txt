Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Elation@Fuze_Max_Profile@CMY_Extended_Pan540@Release%202024-11-11.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

