Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Ayrton@Cobra@Extended_CTO__540@V1.0%20First_Release_4.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

