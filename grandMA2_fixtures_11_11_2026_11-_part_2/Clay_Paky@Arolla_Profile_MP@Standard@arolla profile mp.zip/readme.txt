Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Clay_Paky@Arolla_Profile_MP@Standard@arolla%20profile%20mp.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

