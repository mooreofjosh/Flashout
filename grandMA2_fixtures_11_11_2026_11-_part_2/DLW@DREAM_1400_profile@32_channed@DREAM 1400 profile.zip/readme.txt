Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "DLW@DREAM_1400_profile@32_channed@DREAM%201400%20profile.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

