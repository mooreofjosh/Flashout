Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Cameo@OTOS_H5@32-CH@3DS%20Testfile.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

