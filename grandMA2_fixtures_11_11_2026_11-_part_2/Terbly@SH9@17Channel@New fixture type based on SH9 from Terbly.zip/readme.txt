Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Terbly@SH9@17Channel@New%20fixture%20type%20based%20on%20SH9%20from%20Terbly.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

