Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "LIGHT_SKY@F1700Prifile@S1700WB-PS@New%20fixture%20type%20based%20on%20F1700Prifile%20from%20LIGHT%20SKY.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

