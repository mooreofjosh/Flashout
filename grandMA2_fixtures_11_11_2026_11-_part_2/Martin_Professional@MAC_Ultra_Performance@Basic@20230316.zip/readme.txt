Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Martin_Professional@MAC_Ultra_Performance@Basic@20230316.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

