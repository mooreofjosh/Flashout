Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Ayrton@Domino_Profile@Extended_540@created%20by%20Rene%20-%20finished%20v4.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

