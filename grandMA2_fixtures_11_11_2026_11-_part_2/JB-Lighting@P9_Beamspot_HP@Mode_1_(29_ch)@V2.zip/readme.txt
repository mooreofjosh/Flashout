Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "JB-Lighting@P9_Beamspot_HP@Mode_1_(29_ch)@V2.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

