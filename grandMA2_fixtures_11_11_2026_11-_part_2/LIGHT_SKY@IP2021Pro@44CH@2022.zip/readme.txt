Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "LIGHT_SKY@IP2021Pro@44CH@2022.12.27.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

