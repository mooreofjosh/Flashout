Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "PRstage@F-Spot_800_CMY@Mode_2@Final%20From%20GTDF.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

