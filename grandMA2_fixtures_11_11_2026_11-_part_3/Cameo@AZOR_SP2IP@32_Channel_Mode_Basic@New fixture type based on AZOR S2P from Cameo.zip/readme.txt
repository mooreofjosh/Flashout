Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Cameo@AZOR_SP2IP@32_Channel_Mode_Basic@New%20fixture%20type%20based%20on%20AZOR%20S2P%20from%20Cameo.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

