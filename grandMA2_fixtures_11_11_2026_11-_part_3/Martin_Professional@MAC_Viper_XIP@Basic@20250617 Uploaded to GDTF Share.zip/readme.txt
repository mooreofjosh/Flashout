Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Martin_Professional@MAC_Viper_XIP@Basic@20250617%20Uploaded%20to%20GDTF%20Share._2.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

