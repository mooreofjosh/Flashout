Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "ADJ@Hydro_Hybrid@32Ch@24-13-08%20Release.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

