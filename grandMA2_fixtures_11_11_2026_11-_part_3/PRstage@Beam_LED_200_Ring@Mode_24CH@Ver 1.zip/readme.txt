Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "PRstage@Beam_LED_200_Ring@Mode_24CH@Ver%201.1.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

