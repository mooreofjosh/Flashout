Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "BeamZ_Pro@Nereid_700_IP65@44_Ch@New%20fixture%20type%20based%20on%20Nereid%20700%20from%20BeamZ%20Pro_2.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

