Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "China@ALED_BSW_400@Mode_1@New%20fixture%20type%20based%20on%20ALED%20BSW%20400%20from%20China.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

