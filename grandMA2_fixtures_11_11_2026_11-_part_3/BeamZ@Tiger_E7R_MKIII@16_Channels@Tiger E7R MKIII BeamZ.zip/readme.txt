Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "BeamZ@Tiger_E7R_MKIII@16_Channels@Tiger%20E7R%20MKIII%20BeamZ.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

