Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Ayrton@Rivale_Profile@Standard__540@V1.0%20First_Release_24.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

