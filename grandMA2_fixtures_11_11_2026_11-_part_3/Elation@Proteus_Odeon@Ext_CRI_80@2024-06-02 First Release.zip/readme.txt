Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Elation@Proteus_Odeon@Ext_CRI_80@2024-06-02%20First%20Release.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

