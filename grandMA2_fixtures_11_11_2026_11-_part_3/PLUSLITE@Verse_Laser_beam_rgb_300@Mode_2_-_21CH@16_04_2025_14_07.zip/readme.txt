Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "PLUSLITE@Verse_Laser_beam_rgb_300@Mode_2_-_21CH@16_04_2025_14_07.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

