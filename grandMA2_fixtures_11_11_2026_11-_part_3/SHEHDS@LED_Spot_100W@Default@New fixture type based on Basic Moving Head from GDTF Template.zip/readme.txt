Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "SHEHDS@LED_Spot_100W@Default@New%20fixture%20type%20based%20on%20Basic%20Moving%20Head%20from%20GDTF%20Template.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

