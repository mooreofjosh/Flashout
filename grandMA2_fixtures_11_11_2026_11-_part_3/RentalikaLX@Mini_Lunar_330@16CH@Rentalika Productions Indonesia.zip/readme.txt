Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "RentalikaLX@Mini_Lunar_330@16CH@Rentalika%20Productions%20Indonesia.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

