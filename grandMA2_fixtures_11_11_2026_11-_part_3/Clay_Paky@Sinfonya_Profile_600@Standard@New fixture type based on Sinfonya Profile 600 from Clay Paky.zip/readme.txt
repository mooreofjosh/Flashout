Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Clay_Paky@Sinfonya_Profile_600@Standard@New%20fixture%20type%20based%20on%20Sinfonya%20Profile%20600%20from%20Clay%20Paky.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

