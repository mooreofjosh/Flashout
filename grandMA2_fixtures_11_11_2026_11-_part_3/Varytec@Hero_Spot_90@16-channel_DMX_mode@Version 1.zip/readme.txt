Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Varytec@Hero_Spot_90@16-channel_DMX_mode@Version%201.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

