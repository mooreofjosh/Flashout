Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Ayrton@Kyalami@Extended_540@V1.2%20Add_Control_V106.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

