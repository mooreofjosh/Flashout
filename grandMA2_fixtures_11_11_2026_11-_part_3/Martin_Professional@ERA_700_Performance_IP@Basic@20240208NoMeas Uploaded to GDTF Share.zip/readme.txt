Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Martin_Professional@ERA_700_Performance_IP@Basic@20240208NoMeas%20Uploaded%20to%20GDTF%20Share..xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

