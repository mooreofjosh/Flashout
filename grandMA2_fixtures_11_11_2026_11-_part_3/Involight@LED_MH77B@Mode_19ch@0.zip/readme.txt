Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Involight@LED_MH77B@Mode_19ch@0.1%20Beta%20for%20learning_3.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

