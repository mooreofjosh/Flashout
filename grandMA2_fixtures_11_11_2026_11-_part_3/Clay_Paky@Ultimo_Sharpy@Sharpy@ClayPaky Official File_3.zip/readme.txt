Installation instructions for grandMA2 onPC and MA 3D:

- Library installation
--- Copy file "Clay_Paky@Ultimo_Sharpy@Sharpy@ClayPaky%20Official%20File_3.xml" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/library"

- Gobo installation:
--- Copy/merge contents of folder "gobos" to folder "<SYSTEM_DRIVE>:/ProgramData/MA Lighting Technologies/grandma/gma2_V_<VERSION>/gobos/"

